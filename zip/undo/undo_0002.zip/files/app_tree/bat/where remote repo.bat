git remote -v

pause